## 1. Simulate two-sided matching data for 20 markets (m=20) with 100 students
##    (nStudents=100) per market and 20 colleges with quotas of 5 students, each
##    (nSlots=rep(5,20)).

m <- 20
nStudents <- 100
nSlots <- rep(5,20)
nColleges <- length(nSlots)

xdata <- stabsim2(m=m, nStudents=nStudents, nSlots=nSlots, 
                  colleges = c("c1","c2"),
                  students = c("s1","s2"),
                  outcome = ~ c1:s1 + c2:s2 + eta + delta + nu,
                  selection = list(student = ~ -1 + c1:s1 + eta, 
                                   college = ~ -1 + c2:s2 + delta)
)
head(xdata$OUT)
head(xdata$SELc)
head(xdata$SELs)

## 2-a. Bias from sorting
(lm1 <- lm(y ~ c1:s1 + c2:s2, data=xdata$OUT))

## 2-b. Cause of the bias
with(xdata$OUT, cor(c1*s1, eta + delta))

## 2-c. Correction for sorting bias
(lmc <- lm(Vc ~ -1 + c2:s2, data=xdata$SELc))
(lms <- lm(Vs ~ -1 + c1:s1, data=xdata$SELs))

etahat <- lmc$residuals[xdata$SELc$D==1]
deltahat <- lms$residuals[xdata$SELs$D==1]

(lm2 <- lm(y ~ c1:s1 + c2:s2 + etahat + deltahat, data=xdata$OUT))


## 3. Correction for sorting bias when match valuation V is unobserved

## 3-a. Obtain preference matrices for all markets

hc <- split(xdata$SELc, xdata$SELc$m.id)
hs <- split(xdata$SELs, xdata$SELs$m.id)
c.prefs <- lapply(hs, function(z) with(z, matrix(Vs[order(m.id,c.id,s.id)], ncol=nColleges, nrow=nStudents, byrow=FALSE)))
s.prefs <- lapply(hc, function(z) with(z, matrix(Vc[order(m.id,c.id,s.id)], ncol=nStudents, nrow=nColleges, byrow=TRUE)))
rm(hc,hs)

## convert preferences to ranks in matrix format
c.prefs <- lapply(c.prefs, function(z) apply(-1*z, 2, order))
s.prefs <- lapply(s.prefs, function(z) apply(-1*z, 2, order))


## 3-b. Run Gibbs sampler 
fit2 <- stabit2(OUT = xdata$OUT, #SEL = xdata$SEL
                SEL = list(SELs=xdata$SELs, SELc=xdata$SELc, 
                           c.prefs=c.prefs, s.prefs=s.prefs),
                colleges=c("c1","c2"), students=c("s1","s2"),
                outcome = y ~ c1:s1 + c2:s2,
                selection = list(student = ~ -1 + c1:s1, 
                                 college = ~ -1 + c2:s2),
                niter=1000
)

## 3-c. Run Gibbs sampler (selection only)
fit2 <- stabit2(SEL = list(SELs=xdata$SELs, SELc=xdata$SELc, 
                           c.prefs=c.prefs, s.prefs=s.prefs),
                colleges=c("c1","c2"), students=c("s1","s2"),
                selection = list(student = ~ -1 + c1:s1, 
                                 college = ~ -1 + c2:s2),
                niter=1000
)


## 4-a. Get marginal effects (for linear model)
coefficients(fit2)

## 4-b. Get marginal effects (for probit)
summary(fit2)


## 5. Plot MCMC draws for coefficients
 plot(fit2)



