## 1. Simulate one-sided matching data for 200 markets (m=200) with 2 groups
##    per market (gpm=2) and 5 individuals per group (ind=5). True parameters 
##    in selection equation is wst=1, in outcome equation wst=0. 

## 1-a. Simulate individual-level, independent variables
idata <- stabsim(m=200, ind=5, seed=123, gpm=2)
head(idata)

## 1-b. Simulate group-level variables 
mdata <- stabit(x=idata, simulation="NTU", method="model.frame",
                selection = list(add="wst"), outcome = list(add="wst"))
head(mdata$OUT)
head(mdata$SEL)


## 2. Bias from sorting

## 2-a. Naive OLS estimation
lm(R ~ wst.add, data=mdata$OUT)$coefficients

## 2-b. epsilon is correlated with independent variables
with(mdata$OUT, cor(epsilon, wst.add))

## 2-c. but xi is uncorrelated with independent variables
with(mdata$OUT, cor(xi, wst.add))

## 3. Correction of sorting bias when valuations V are observed

## 3-a. 1st stage: obtain fitted value for eta
lm.sel <- lm(V ~ -1 + wst.add, data=mdata$SEL)
lm.sel$coefficients

eta <- lm.sel$resid[mdata$SEL$D==1]

## 3-b. 2nd stage: control for eta
lm(R ~ wst.add + eta, data=mdata$OUT)$coefficients


## 4. Run Gibbs sampler
fit1 <- stabit(x=idata, method="NTU", simulation="NTU", censored=1, 
               selection = list(ieq="wst"), outcome = list(ieq="wst"), 
               niter=2000)


## 5. Coefficient table
summary(fit1)


## 6. Plot MCMC draws for coefficients
plot(fit1)




