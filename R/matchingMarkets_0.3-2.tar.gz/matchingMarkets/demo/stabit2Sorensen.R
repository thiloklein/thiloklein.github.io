## 1. Simulate two-sided matching data for 20 markets (m=20) with 100 students
##    (nStudents=100) per market and 20 colleges with quotas of 5 students, each
##    (nSlots=rep(5,20)). True parameters in selection and outcome equations are 
##    all equal to 1.

xdata <- stabsim2(m=20, nStudents=100, nSlots=rep(5,20), 
                  colleges = "c1",
                  students = "s1",
                  outcome = ~ c1:s1 + eta + nu,
                  selection = ~ -1 + c1:s1 + eta
)
head(xdata$OUT)


## 2. Correction for sorting bias when match valuations V are observed

## 2-a. Bias from sorting
lm1 <- lm(y ~ c1:s1, data=xdata$OUT)
summary(lm1)

## 2-b. Cause of the bias
with(xdata$OUT, cor(c1*s1, eta))

## 2-c. Correction for sorting bias
lm2a <- lm(V ~ -1 + c1:s1, data=xdata$SEL); summary(lm2a)
etahat <- lm2a$residuals[xdata$SEL$D==1]

lm2b <- lm(y ~ c1:s1 + etahat, data=xdata$OUT)
summary(lm2b)


## 3. Correction for sorting bias when match valuations V are unobserved

## 3-a. Run Gibbs sampler (when SEL is given)
fit2 <- stabit2(OUT = xdata$OUT, 
                SEL = xdata$SEL,
                outcome = y ~ c1:s1, 
                selection = ~ -1 + c1:s1,
                niter=1000
)

## 3-b. Alternatively: Run Gibbs sampler (when SEL is not given)
fit2 <- stabit2(OUT = xdata$OUT, 
                colleges = "c1",
                students = "s1",
                outcome = y ~ c1:s1, 
                selection = ~ -1 + c1:s1,
                niter=1000
)


## 4. Implemented methods

## 4-a. Get coefficients
fit2

## 4-b. Coefficient table
summary(fit2)

## 4-c. Get marginal effects
summary(fit2, mfx=TRUE)

## 4-d. Also try the following functions
coef(fit2)
fitted(fit2)
residuals(fit2)
predict(fit2, newdata=NULL)


## 5. Plot MCMC draws for coefficients
plot(fit2)



