

## Algorithms
hri <- sd_icon({})
iaa <- sd_icon({})
sri <- sd_icon({})
ttc <- sd_icon({})

## Estimators
stabit <- sd_icon({})
stabit2 <- sd_icon({})

## Data generation
stabsim <- sd_icon({})
stabsim2 <- sd_icon({})

